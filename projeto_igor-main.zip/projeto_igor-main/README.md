1- criando base do projeto
